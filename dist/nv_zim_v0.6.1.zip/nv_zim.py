"""Zim Desktop Wiki connection plugin for novelibre.

Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_zim
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
from tkinter import ttk
import webbrowser

from abc import ABC, abstractmethod



class SubController:

    def initialize_controller(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self.initialize_controller(model, view, controller)

import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_zim', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

import glob
import subprocess
from tkinter import filedialog



class ServiceBase:

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
from tkinter import messagebox
from tkinter import ttk

import calendar

try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation('novelibre', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
        _ = t.gettext
    except:

        def _(message):
            return message

WEEKDAYS = calendar.day_name
MONTHS = calendar.month_name

import tkinter as tk


class SimpleDialog:

    def __init__(self, master,
                 text='', buttons=[], default=None, cancel=None,
                 title=None, class_=None):
        if class_:
            self.root = tk.Toplevel(master, class_=class_)
        else:
            self.root = tk.Toplevel(master)
        if title:
            self.root.title(title)
            self.root.iconname(title)

        _setup_dialog(self.root)

        self.message = tk.Message(self.root, text=text, aspect=400, bg='white')
        self.message.pack(expand=1, fill='both')
        self.frame = ttk.Frame(self.root)
        self.frame.pack()
        self.num = default
        self.cancel = cancel
        self.default = default
        self.root.bind('<Return>', self.return_event)
        for num in range(len(buttons)):
            s = buttons[num]
            b = ttk.Button(
                self.frame,
                text=s,
                command=(lambda self=self, num=num: self.done(num))
                )
            if num == default:
                b.configure(default='active')
            b.pack(side='left', fill='both', expand=1, padx=5, pady=10)
        self.root.protocol('WM_DELETE_WINDOW', self.wm_delete_window)
        self.root.transient(master)
        _place_window(self.root, master)

    def go(self):
        self.root.wait_visibility()
        self.root.lift()
        self.root.focus_force()
        self.root.grab_set()
        self.root.mainloop()
        self.root.destroy()
        return self.num

    def return_event(self, event):
        if self.default is None:
            self.root.bell()
        else:
            self.done(self.default)

    def wm_delete_window(self):
        if self.cancel is None:
            self.root.bell()
        else:
            self.done(self.cancel)

    def done(self, num):
        self.num = num
        self.root.quit()


class Dialog(tk.Toplevel):


    def __init__(self, parent, title=None):
        master = parent
        tk.Toplevel.__init__(self, master)

        self.withdraw()  # remain invisible for now
        if parent is not None and parent.winfo_viewable():
            self.transient(parent)

        if title:
            self.title(title)

        _setup_dialog(self)

        self.parent = parent

        self.result = None

        body = ttk.Frame(self)
        self.initial_focus = self.body(body)
        body.pack(padx=5, pady=5)

        self.buttonbox()

        if self.initial_focus is None:
            self.initial_focus = self

        self.protocol('WM_DELETE_WINDOW', self.cancel)

        _place_window(self, parent)

        self.initial_focus.focus_set()

        self.wait_visibility()
        self.grab_set()
        self.wait_window(self)

    def destroy(self):
        self.initial_focus = None
        tk.Toplevel.destroy(self)


    def body(self, master):
        pass

    def buttonbox(self):

        box = ttk.Frame(self)

        w = ttk.Button(box, text=_('OK'), width=10, command=self.ok, default='active')
        w.pack(side='left', padx=5, pady=10)
        w = ttk.Button(box, text=_('Cancel'), width=10, command=self.cancel)
        w.pack(side='left', padx=5, pady=10)

        self.bind('<Return>', self.ok)
        self.bind('<Escape>', self.cancel)

        box.pack()


    def ok(self, event=None):

        if not self.validate():
            self.initial_focus.focus_set()  # put focus back
            return

        self.withdraw()
        self.update_idletasks()

        try:
            self.apply()
        finally:
            self.cancel()

    def cancel(self, event=None):

        if self.parent is not None:
            self.parent.focus_set()
        self.destroy()


    def validate(self):

        return 1  # override

    def apply(self):

        pass  # override


def _place_window(w, parent=None):
    w.wm_withdraw()  # Remain invisible while we figure out the geometry
    w.update_idletasks()  # Actualize geometry information

    minwidth = w.winfo_reqwidth()
    minheight = w.winfo_reqheight()
    maxwidth = w.winfo_vrootwidth()
    maxheight = w.winfo_vrootheight()
    if parent is not None and parent.winfo_ismapped():
        x = parent.winfo_rootx() + (parent.winfo_width() - minwidth) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - minheight) // 2
        vrootx = w.winfo_vrootx()
        vrooty = w.winfo_vrooty()
        x = min(x, vrootx + maxwidth - minwidth)
        x = max(x, vrootx)
        y = min(y, vrooty + maxheight - minheight)
        y = max(y, vrooty)
        if w._windowingsystem == 'aqua':
            y = max(y, 22)
    else:
        x = (w.winfo_screenwidth() - minwidth) // 2
        y = (w.winfo_screenheight() - minheight) // 2

    w.wm_maxsize(maxwidth, maxheight)
    w.wm_geometry('+%d+%d' % (x, y))
    w.wm_deiconify()  # Become visible at the desired location


def _setup_dialog(w):
    if w._windowingsystem == 'aqua':
        w.tk.call('::tk::unsupported::MacWindowStyle', 'style',
                  w, 'moveableModal', '')
    elif w._windowingsystem == 'x11':
        w.wm_attributes('-type', 'dialog')



class _QueryDialog(Dialog):

    def __init__(self, title, prompt,
                 initialvalue=None,
                 minvalue=None, maxvalue=None,
                 parent=None):

        self.prompt = prompt
        self.minvalue = minvalue
        self.maxvalue = maxvalue

        self.initialvalue = initialvalue

        Dialog.__init__(self, parent, title)

    def destroy(self):
        self.entry = None
        Dialog.destroy(self)

    def body(self, master):

        w = ttk.Label(master, text=self.prompt, justify='left')
        w.grid(row=0, padx=5, sticky='w')

        self.entry = ttk.Entry(master, name='entry')
        self.entry.grid(row=1, padx=5, pady=5, sticky='w' + 'e')

        if self.initialvalue is not None:
            self.entry.insert(0, self.initialvalue)
            self.entry.select_range(0, 'end')

        return self.entry

    def validate(self):
        try:
            result = self.getresult()
        except ValueError:
            messagebox.showwarning(
                _('Illegal value'),
                f'{self.errormessage}\n{_("Please try again")}.',
                parent=self
            )
            return 0

        if self.minvalue is not None and result < self.minvalue:
            messagebox.showwarning(
                _('Too small'),
                f'{_("The allowed minimum value is")} {self.minvalue}.\n{_("Please try again")}.',
                parent=self
            )
            return 0

        if self.maxvalue is not None and result > self.maxvalue:
            messagebox.showwarning(
                _('Too large'),
                f'{_("The allowed maximum value is")} {self.maxvalue}.\n{_("Please try again")}.',
                parent=self
            )
            return 0

        self.result = result

        return 1


class _QueryInteger(_QueryDialog):
    errormessage = _('Not an integer.')

    def getresult(self):
        return self.getint(self.entry.get())


def askinteger(title, prompt, **kw):
    d = _QueryInteger(title, prompt, **kw)
    return d.result


class _QueryFloat(_QueryDialog):
    errormessage = _('Not a floating point value.')

    def getresult(self):
        return self.getdouble(self.entry.get())


def askfloat(title, prompt, **kw):
    d = _QueryFloat(title, prompt, **kw)
    return d.result


class _QueryString(_QueryDialog):

    def __init__(self, *args, **kw):
        if 'show' in kw:
            self.__show = kw['show']
            del kw['show']
        else:
            self.__show = None
        _QueryDialog.__init__(self, *args, **kw)

    def body(self, master):
        entry = _QueryDialog.body(self, master)
        if self.__show is not None:
            entry.configure(show=self.__show)
        return entry

    def getresult(self):
        return self.entry.get()


def askstring(title, prompt, **kw):
    d = _QueryString(title, prompt, **kw)
    return d.result

from datetime import date
from datetime import time

ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
XREF_SUFFIX = '_xref'


class Error(Exception):
    pass


class Notification(Error):
    pass


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_date(dateStr):
    if dateStr is not None:
        date.fromisoformat(dateStr)
    return dateStr


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr


def verified_time(timeStr):
    if  timeStr is not None:
        time.fromisoformat(timeStr)
        while timeStr.count(':') < 2:
            timeStr = f'{timeStr}:00'
    return timeStr

from datetime import date

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_zim', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

ZIM_NOTEBOOK_ABS_TAG = 'zim-notebook-abs'
ZIM_NOTEBOOK_REL_TAG = 'zim-notebook-rel'
ZIM_PAGE_ABS_TAG = 'zim-page-abs'
ZIM_PAGE_REL_TAG = 'zim-page-rel'


class StopParsing(Exception):
    pass


def fix_file_name(fileName):
    FORBIDDEN_CHARACTERS = ('\\', '/', ':', '*', '?', '"', '<', '>', '|')
    for c in FORBIDDEN_CHARACTERS:
        fileName = fileName.replace(c, '')
    return fileName.replace(' ', '_')


def locale_date(isoDate):
    try:
        newDate = date.fromisoformat(isoDate)
        return newDate.strftime('%x')

    except:
        return isoDate


class ZimPage:

    DESCRIPTION = _('Zim page')
    EXTENSION = '.txt'

    PAGE_HEADER = '''Content-Type: text/x-zim-wiki
Wiki-Format: zim 0.4
'''
    REPLACEMENTS = {
        '//':'',
        '**': '',
    }

    def __init__(self, filePath, element):
        self.filePath = filePath
        self.element = element
        self.page_names = [self.element.title]

    def body(self, text):
        pass

    def fill_page(self, lines):
        pass

    def from_wiki(self, text):
        for tag in self.REPLACEMENTS:
            text = text.replace(tag, self.REPLACEMENTS[tag])
        return text

    def get_h1(self, text):
        return f'====== {text} ======\n'

    def get_h2(self, text):
        return f'===== {text} =====\n'

    def get_h3(self, text):
        return f'==== {text} ====\n'

    def h1(self, heading):
        if self.element.title is None:
            self.element.title = heading

    def h2(self, heading):
        pass

    def h3(self, heading):
        pass

    def new_page_name(self):
        for name in self.page_names:
            if name is not None:
                return name

    def parse_line(self, line):
        if line.startswith('====== '):
            heading = line.strip('= ')
            self.h1(heading)

        if line.startswith('===== '):
            heading = line.strip('= ')
            self.h2(heading)

        if line.startswith('==== '):
            heading = line.strip('= ')
            self.h3(heading)

        elif not line.startswith('='):
            self.body(line)

    def read(self):
        with open (self.filePath, 'r', encoding='utf-8') as f:
            text = f.read()
        lines = text.split('\n')
        for line in lines:
            try:
                self.parse_line(line)
            except StopParsing:
                return

    def write(self):
        lines = [
            self.PAGE_HEADER,
            f'{self.get_h1(self.new_page_name())}',
        ]
        self.fill_page(lines)
        text = '\n'.join(lines)
        with open (self.filePath, 'w', encoding='utf-8') as f:
            f.write(text)


class BookPage(ZimPage):

    pass


class WorldElementPage(ZimPage):

    def __init__(self, filePath, element):
        super().__init__(filePath, element)
        self.page_names = [self.element.title]

    def fill_page(self, lines):
        if self.element.aka:
            lines.append(self.element.aka)
            lines.append('\n')

        if self.element.tags:
            for tag in self.element.tags:
                lines.append(f"@{tag.replace(' ', '_')}")
            lines.append('\n')

        if self.element.desc:
            lines.append(self.element.desc)
            lines.append('\n')


class CharacterPage(WorldElementPage):

    def __init__(self, filePath, element):
        super().__init__(filePath, element)
        self.page_names = [self.element.fullName, self.element.title, self.element.aka]

    def fill_page(self, lines):
        super().fill_page(lines)

        if self.element.bio:
            lines.append(self.get_h2(_('Bio')))
            self._set_birth_date(lines)
            lines.append(self.element.bio)
            lines.append('\n')
        else:
            self._set_birth_date(lines)
            lines.append('\n')

        if self.element.goals:
            lines.append(self.get_h2(_('Goals')))
            lines.append(self.element.goals)
            lines.append('\n')

    def _set_birth_date(self, lines):
        showDate = False
        if self.element.birthDate:
            startDate = locale_date(self.element.birthDate)
            showDate = True
        else:
            startDate = '?'
        if self.element.deathDate:
            endDate = locale_date(self.element.deathDate)
            showDate = True
        else:
            endDate = '?'
        if showDate:
            lines.append(f'{startDate}—{endDate}\n')

from configparser import ConfigParser



class ZimNotebook:

    DESCRIPTION = _('Zim notebook')
    EXTENSION = '.zim'

    NOTEBOOK = 'Notebook'
    HOME = 'Home'

    def __init__(self, dirPath='', filePath='', wikiName=None):
        if wikiName is None:
            wikiName = self.NOTEBOOK
        self.settings = dict(
            version='0.4',
            name=wikiName,
            interwiki='',
            home=self.HOME,
            icon='',
            document_root='',
            shared='True',
            endofline='dos',
            disable_trash='False',
            profile='',
        )
        if os.path.isfile(filePath):
            self.filePath = filePath
            self.dirPath, __ = os.path.split(filePath)
            self.filePath = filePath
            self.read_settings()
            self.homeDir = f"{self.dirPath}/{self.settings['home']}"
        elif os.path.isdir(dirPath):
            self.dirPath = dirPath
            self.filePath = f'{dirPath}/{self.NOTEBOOK}.zim'
            self.homeDir = f'{self.dirPath}/{self.HOME}'
            self.write()
        else:
            raise AttributeError

    def read_settings(self):
        notebook = ConfigParser()
        notebook.read(self.filePath, encoding='utf-8')
        for tag in self.settings:
            self.settings[tag] = notebook.get(self.NOTEBOOK, tag)

    def write(self):
        notebook = ConfigParser()
        notebook.add_section(self.NOTEBOOK)
        for tag in self.settings:
            notebook.set(self.NOTEBOOK, tag, self.settings[tag])
        with open(self.filePath, 'w', encoding='utf-8') as f:
            notebook.write(f)
        os.makedirs(self.homeDir, exist_ok=True)

    def get_page_path_by_title(self, title):
        foundFiles = glob.glob(
            f'**/{fix_file_name(title)}{ZimPage.EXTENSION}',
            root_dir=self.homeDir,
            recursive=True,
            )
        if foundFiles:
            foundFile = foundFiles[0].replace('\\', '/')
            return f'{self.homeDir}/{foundFile}'



class WikiManager(ServiceBase):

    def __init__(self, model, view, controller, windowTitle):
        super().__init__(model, view, controller)
        self.prjWiki = None
        self.launchers = self._ctrl.get_launchers()
        self.zimApp = self.launchers.get(ZimNotebook.EXTENSION, '')
        self.windowTitle = windowTitle

    def check_home_dir(self):
        if self.prjWiki is None:
            return

        if not os.path.isdir(self.prjWiki.homeDir):
            os.makedirs(self.prjWiki.homeDir)

    def new_wiki_page(self, element, elemId, filePath):
        if elemId == CH_ROOT:
            return BookPage(filePath, element)

        if elemId.startswith(CHARACTER_PREFIX):
            return CharacterPage(filePath, element)

        if elemId.startswith(LOCATION_PREFIX):
            return WorldElementPage(filePath, element)

        if elemId.startswith(ITEM_PREFIX):
            return WorldElementPage(filePath, element)

    def get_element(self, elemId):
        if elemId.startswith(CHARACTER_PREFIX):
            return self._mdl.novel.characters[elemId]

        if elemId.startswith(LOCATION_PREFIX):
            return self._mdl.novel.locations[elemId]

        if elemId.startswith(ITEM_PREFIX):
            return self._mdl.novel.items[elemId]

        if elemId.startswith(CH_ROOT):
            return self._mdl.novel

    def get_project_wiki_link(self):
        if self._mdl.prjFile is None:
            return

        prjWikiPath = self._mdl.novel.fields.get(ZIM_NOTEBOOK_ABS_TAG, None)
        if prjWikiPath is None:
            prjWikiPath = self._mdl.novel.fields.get(ZIM_NOTEBOOK_REL_TAG, None)
            if prjWikiPath is None:
                return

            prjWikiPath = self._ctrl.linkProcessor.expand_path(prjWikiPath)

        if not prjWikiPath.endswith(ZimNotebook.EXTENSION):
            return

        if os.path.isfile(prjWikiPath):
            return prjWikiPath

    def get_wiki_page_link(self, element):
        wikiPagePath = element.fields.get(ZIM_PAGE_ABS_TAG, None)
        if wikiPagePath is None:
            wikiPagePath = element.fields.get(ZIM_PAGE_REL_TAG, None)
            if wikiPagePath is None:
                return

            wikiPagePath = self._ctrl.linkProcessor.expand_path(wikiPagePath)

        if not wikiPagePath.endswith(ZimPage.EXTENSION):
            return

        if os.path.isfile(wikiPagePath):
            return wikiPagePath

    def on_close(self):
        self.prjWiki = None

    def open_element_page(self, elemId):
        self._ui.restore_status()
        element = self.get_element(elemId)

        filePath = self.get_wiki_page_link(element)
        pageCreated = False

        if filePath is None:

            wikiPage = self.new_wiki_page(element, elemId, None)
            self.set_project_wiki()
            if self.prjWiki is not None:
                for pageName in wikiPage.page_names:
                    if not pageName:
                        continue

                    filePath = self.prjWiki.get_page_path_by_title(pageName)
                    if filePath is not None:
                        break

        if filePath is None:

            text = f"{_('Wiki page not found')}\n\n{_('Open an existing page, or create a new one?')}"
            answer = SimpleDialog(
                None,
                text=text,
                buttons=[_('Browse'), _('Create'), _('Cancel')],
                default=0,
                cancel=2,
                title=self.windowTitle
                ).go()

            if answer == 2:
                return

            if answer == 0:

                filePath = filedialog.askopenfilename(
                    filetypes=[(ZimPage.DESCRIPTION, ZimPage.EXTENSION)],
                    defaultextension=ZimPage.EXTENSION,
                    initialdir=os.path.split(self._mdl.prjFile.filePath)[0]
                    )
                if not filePath:
                    return

            else:
                if self._ctrl.check_lock():
                    return

                if self.prjWiki is None:
                    return

                self.check_home_dir()
                pageName = fix_file_name(wikiPage.new_page_name())
                filePath = f'{self.prjWiki.homeDir}/{pageName}{wikiPage.EXTENSION}'
                wikiPage.filePath = filePath
                wikiPage.write()
                pageCreated = True

        self.set_page_links(element, filePath)
        if pageCreated:
            self._ui.set_status(_('Wiki page created'))

            subprocess.Popen([
                self.zimApp,
                '--index',
                filePath,
                ])
        self.open_page_file(filePath)

    def open_project_wiki(self):
        self._ui.restore_status()
        self._ui.propertiesView.apply_changes()
        if not self.zim_is_installed():
            self._ui.set_status(f'!{_("Zim installation not found")}.')
            return

        self.set_project_wiki()
        self.check_home_dir()
        if self.prjWiki is not None:
            subprocess.Popen([
                self.zimApp,
                self.prjWiki.filePath,
                self.prjWiki.settings['home']
                ])

    def open_page_file(self, filePath):
        if not self.zim_is_installed():
            self._ui.set_status(f'!{_("Zim installation not found")}.')
            return

        root, extension = os.path.splitext(filePath)
        if extension != ZimPage.EXTENSION:
            return False

        pagePath = root.split('/')
        zimPages = []

        while pagePath:
            zimPages.insert(0, pagePath.pop())
            zimPath = '/'.join(pagePath)
            zimNotebook = glob.glob(norm_path(f'{zimPath}/*{ZimNotebook.EXTENSION}'))
            if zimNotebook:
                subprocess.Popen([
                    self.zimApp,
                    zimNotebook[0],
                    ":".join(zimPages)
                    ])
                return True

        return False

    def set_notebook_links(self, prjWikiPath):
        self._ui.restore_status()
        if self._ctrl.isLocked:
            return

        fields = self._mdl.novel.fields
        initialAbsPath = fields.get(ZIM_NOTEBOOK_ABS_TAG, None)
        initialRelPath = fields.get(ZIM_NOTEBOOK_REL_TAG, None)
        fields[ZIM_NOTEBOOK_ABS_TAG] = prjWikiPath
        relPath = self._ctrl.linkProcessor.shorten_path(prjWikiPath)
        fields[ZIM_NOTEBOOK_REL_TAG] = relPath
        self._mdl.novel.fields = fields
        message = None
        if initialAbsPath is None or initialRelPath is None:
            message = f"#{_('Wiki link created')}"
        elif initialAbsPath != prjWikiPath  or initialRelPath != relPath:
            message = f"#{_('Broken link fixed')}"
        if message is not None:
            self._ui.set_status(message)

    def set_page_links(self, element, wikiPagePath):
        self._ui.restore_status()
        if self._ctrl.isLocked:
            return

        fields = element.fields
        initialAbsPath = fields.get(ZIM_PAGE_ABS_TAG, None)
        initialRelPath = fields.get(ZIM_PAGE_REL_TAG, None)
        fields[ZIM_PAGE_ABS_TAG] = wikiPagePath
        relPath = self._ctrl.linkProcessor.shorten_path(wikiPagePath)
        fields[ZIM_PAGE_REL_TAG] = relPath
        element.fields = fields
        message = None
        if initialAbsPath is None or initialRelPath is None:
            message = f"#{_('Wiki link created')}"
        elif initialAbsPath != wikiPagePath  or initialRelPath != relPath:
            message = f"#{_('Broken link fixed')}"
        if message is not None:
            self._ui.set_status(message)

    def set_project_wiki(self):
        if self.prjWiki is not None:
            return

        prjWikiPath = self.get_project_wiki_link()
        if prjWikiPath is not None and os.path.isfile(prjWikiPath):

            self.prjWiki = ZimNotebook(filePath=prjWikiPath)
            self.set_notebook_links(self.prjWiki.filePath)
            return

        text = f"{_('Project wiki not found')}\n\n{_('Open an existing wiki, or create a new one?')}"
        answer = SimpleDialog(
            None,
            text=text,
            buttons=[_('Browse'), _('Create'), _('Cancel')],
            default=0,
            cancel=2,
            title=self.windowTitle
            ).go()
        if answer == 2:
            return

        if answer == 0:
            prjWikiPath = filedialog.askopenfilename(
                filetypes=[(ZimNotebook.DESCRIPTION, ZimNotebook.EXTENSION)],
                defaultextension=ZimNotebook.EXTENSION,
                initialdir=os.path.split(self._mdl.prjFile.filePath)[0]
                )
            if not prjWikiPath:
                return

            self.prjWiki = ZimNotebook(filePath=prjWikiPath)
            self.set_notebook_links(self.prjWiki.filePath)
        elif not self._ctrl.check_lock():
            prjDir, prjFile = os.path.split(self._mdl.prjFile.filePath)
            prjFileBase = os.path.splitext(prjFile)[0]
            prjWikiDir = f'{prjDir}/{prjFileBase}_zim'
            os.makedirs(prjWikiDir, exist_ok=True)
            self.prjWiki = ZimNotebook(dirPath=prjWikiDir, wikiName=self._mdl.novel.title)
            self.set_notebook_links(self.prjWiki.filePath)
            self._ui.set_status(f'{_("Wiki created")}: "{norm_path(self.prjWiki.filePath)}"')

    def zim_is_installed(self):
        if os.path.isfile(self.zimApp):
            self.launchers[ZimNotebook.EXTENSION] = self.zimApp
            return True

        self.zimInstallPaths = [
            'C:/Program Files/Zim Desktop Wiki/zim.exe',
            'C:/Program Files (x86)/Zim Desktop Wiki/zim.exe',
            ]
        self.zimInstallPaths.clear()
        for zimPath in self.zimInstallPaths:
            if os.path.isfile(zimPath):
                self.zimApp = zimPath
                self.launchers[ZimNotebook.EXTENSION] = self.zimApp
                return True

        if not self._ui.ask_yes_no(_('Zim installation not found. Select now?')):
            return

        zimPath = filedialog.askopenfilename()
        if not zimPath:
            return

        self.zimApp = zimPath
        self.launchers[ZimNotebook.EXTENSION] = self.zimApp
        return True



class Plugin(PluginBase):
    VERSION = '0.6.1'
    API_VERSION = '5.0'
    DESCRIPTION = 'Zim Desktop Wiki connection'
    URL = 'https://github.com/peter88213/nv_zim'

    FEATURE = 'Zim Desktop Wiki'
    HELP_URL = 'https://github.com/peter88213/nv_zim/tree/main/docs/nv_zim'

    def disable_menu(self):
        self._ui.toolsMenu.entryconfig(_('Open project wiki'), state='disabled')

    def enable_menu(self):
        self._ui.toolsMenu.entryconfig(_('Open project wiki'), state='normal')

    def install(self, model, view, controller):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the main model instance of the application.
            view -- reference to the main view instance of the application.
            controller -- reference to the main controller instance of the application.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.wikiManager = WikiManager(model, view, controller, self.FEATURE)

        self._ui.helpMenu.add_command(label=_('Zim connection Online help'), command=self.open_help_page)
        self._ui.toolsMenu.add_command(label=_('Open project wiki'), command=self.open_project_wiki)

        self._ctrl.linkProcessor.add_opener(self.open_page_file)

        self.add_buttons()
        self._ui.root.bind('<<RebuildPropertiesView>>', self.add_buttons)

    def add_buttons(self, event=None):
        views = [
            self._ui.propertiesView.characterView,
            self._ui.propertiesView.locationView,
            self._ui.propertiesView.itemView,
            self._ui.propertiesView.projectView,
        ]
        for view in views:
            ttk.Button(
                view.linksWindow.titleBar,
                text=_('Wiki page'),
                command=self.open_element_page
                ).pack(side='right')

    def on_close(self):
        self.wikiManager.on_close()

    def open_element_page(self, event=None):
        elemId = self._ui.propertiesView.activeView.elementId
        self.wikiManager.open_element_page(elemId)

    def open_help_page(self, event=None):
        webbrowser.open(self.HELP_URL)

    def open_page_file(self, event=None):
        self.wikiManager.open_page_file()

    def open_project_wiki(self, event=None):
        self.wikiManager.open_project_wiki()
