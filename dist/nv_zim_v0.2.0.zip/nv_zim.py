"""Plugin template for novelibre.

Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_zim
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import glob
import os
import subprocess
from tkinter import filedialog
from tkinter import ttk

from abc import ABC, abstractmethod



class SubController:

    def initialize_controller(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self.initialize_controller(model, view, controller)

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

from calendar import day_name
from calendar import month_name
from datetime import date
from datetime import time
import gettext
import locale
import sys

ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
XREF_SUFFIX = '_xref'


class Error(Exception):
    pass


class Notification(Error):
    pass


try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation('novelibre', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
        _ = t.gettext
    except:

        def _(message):
            return message

WEEKDAYS = day_name
MONTHS = month_name


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_date(dateStr):
    if dateStr is not None:
        date.fromisoformat(dateStr)
    return dateStr


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr


def verified_time(timeStr):
    if  timeStr is not None:
        time.fromisoformat(timeStr)
        while timeStr.count(':') < 2:
            timeStr = f'{timeStr}:00'
    return timeStr



def open_document(document):
    try:
        os.startfile(norm_path(document))
    except:
        try:
            os.system('xdg-open "%s"' % norm_path(document))
        except:
            try:
                os.system('open "%s"' % norm_path(document))
            except:
                pass
import webbrowser

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_zim', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

HELP_URL = 'https://github.com/peter88213/nv_zim/tree/main/docs/nv_zim'

ZIM_NOTEBOOK_TAG = 'zim-notebook'
ZIM_NOTE_TAG = 'zim-note'
ZIM_NOTE_EXTENSION = '.txt'


class StopParsing(Exception):
    pass


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def open_help(event=None):
    webbrowser.open(HELP_URL)


class ZimNote:

    PAGE_HEADER = '''Content-Type: text/x-zim-wiki
Wiki-Format: zim 0.4
'''
    REPLACEMENTS = {
        '//':'',
        '**': '',
    }

    def __init__(self, filePath, element):
        self.filePath = filePath
        self.element = element

    def body(self, text):
        pass

    def create_link(self):
        fields = self.element.fields
        fields[ZIM_NOTE_TAG] = self.filePath
        self.element.fields = fields

    def fill_page(self, lines):
        pass

    def from_wiki(self, text):
        for tag in self.REPLACEMENTS:
            text = text.replace(tag, self.REPLACEMENTS[tag])
        return text

    def get_h1(self, text):
        return f'====== {text} ======'

    def get_h2(self, text):
        return f'===== {text} ====='

    def get_h3(self, text):
        return f'==== {text} ===='

    def h1(self, heading):
        if self.element.title is None:
            self.element.title = heading

    def h2(self, heading):
        pass

    def h3(self, heading):
        pass

    def new_title(self):
        return self.element.title

    def parse_line(self, line):
        if line.startswith('====== '):
            heading = line.strip('= ')
            self.h1(heading)

        if line.startswith('===== '):
            heading = line.strip('= ')
            self.h2(heading)

        if line.startswith('==== '):
            heading = line.strip('= ')
            self.h3(heading)

        elif not line.startswith('='):
            self.body(line)

    def read(self):
        with open (self.filePath, 'r', encoding='utf-8') as f:
            text = f.read()
        lines = text.split('\n')
        for line in lines:
            try:
                self.parse_line(line)
            except StopParsing:
                return

    def write(self):
        lines = [
            self.PAGE_HEADER,
            f'{self.get_h1(self.new_title())}\n\n',
        ]
        self.fill_page(lines)
        text = '\n'.join(lines)
        with open (self.filePath, 'w', encoding='utf-8') as f:
            f.write(text)
from configparser import ConfigParser



class ZimNotebook:

    NOTEBOOK = 'Notebook'
    HOME = 'Home'

    def __init__(self, novel, dirPath='', filePath=''):
        self.settings = dict(
            version='0.4',
            name=self.NOTEBOOK,
            interwiki='',
            home=self.HOME,
            icon='',
            document_root='',
            shared='True',
            endofline='dos',
            disable_trash='False',
            profile='',
        )
        self._novel = novel
        if os.path.isfile(filePath):
            self.filePath = filePath
            self.dirPath, __ = os.path.split(filePath)
            self.filePath = filePath
            self.read_settings()
            self.homeDir = f'{self.dirPath}/{self.settings["home"]}'
        elif os.path.isdir(dirPath):
            self.dirPath = dirPath
            self.filePath = f'{dirPath}/{self.NOTEBOOK}.zim'
            self.homeDir = f'{self.dirPath}/{self.HOME}'
            self.write()
        else:
            raise AttributeError

    def create_link(self):
        fields = self.novel.fields
        fields[ZIM_NOTEBOOK_TAG] = self.dirPath
        self._novel.fields = fields

    def read_settings(self):
        notebook = ConfigParser()
        notebook.read(self.filePath, encoding='utf-8')
        for tag in self.settings:
            self.settings[tag] = notebook.get(self.NOTEBOOK, tag)

    def write(self):
        notebook = ConfigParser()
        notebook.add_section()
        for tag in self.settings:
            notebook.set(self.NOTEBOOK, tag, self.settings[tag])
        with open(self.filePath, 'w', encoding='utf-8') as f:
            notebook.write(f)
        os.makedirs(self.homeDir, exist_ok=True)

    def get_note(self, title):
        foundFiles = glob.glob(
            f'**/{title}{ZIM_NOTE_EXTENSION}',
            root_dir=self.homeDir,
            recursive=True,
            )
        if foundFiles:
            foundFile = foundFiles[0].replace('\\', '/')
            return f'{self.homeDir}/{foundFile}'



class Plugin(PluginBase):
    VERSION = '0.2.0'
    API_VERSION = '5.0'
    DESCRIPTION = 'Zim Desktop Wiki connector'
    URL = 'https://github.com/peter88213/nv_zim'

    FEATURE = 'Zim Desktop Wiki'

    def install(self, model, view, controller):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the main model instance of the application.
            view -- reference to the main view instance of the application.
            controller -- reference to the main controller instance of the application.

        Optional arguments:
            prefs -- deprecated. Please use controller.get_preferences() instead.
        
        Extends the superclass method.
        """
        super().install(model, view, controller)

        self._ui.helpMenu.add_command(label=_('nv_zim Online help'), command=open_help)
        self._ui.toolsMenu.add_command(label=_('Open project wiki'), command=self.open_project_wiki)

        self._ctrl.linkProcessor.add_opener(self.open_zim_page)

        ttk.Button(
            self._ui.propertiesView.characterView.linksWindow.titleBar,
            text=_('Wiki page'),
            command=self.open_element_page
            ).pack(side='right')

        self._ZimNotebookType = [('Zim Wiki', '.zim')]
        self._ZimNoteType = [('Zim Note', '.txt')]
        self.prjWiki = None

    def create_wiki_page(self, element):
        wikiPath = os.path.split(self.prjWiki.filePath)[0]
        filePath = f'{wikiPath}/Home/{element.title}{ZIM_NOTE_EXTENSION}'
        newPage = ZimNote(filePath, element)
        newPage.write()
        newPage.create_link()
        return filePath

    def get_project_wiki_path(self):
        if self._mdl.prjFile is None:
            return

        prjWikiPath = self._mdl.novel.fields.get(ZIM_NOTEBOOK_TAG, '')
        if os.path.isfile(prjWikiPath):
            return prjWikiPath

        prjWikiPath = filedialog.askopenfilename(
            filetypes=self._ZimNotebookType,
            defaultextension=self._ZimNotebookType[0][1],
            initialdir=os.path.split(self._mdl.prjFile.filePath)[0]
            )
        if prjWikiPath:
            fields = self._mdl.novel.fields
            fields[ZIM_NOTEBOOK_TAG] = prjWikiPath
            self._mdl.novel.fields = fields
            return prjWikiPath

    def get_zim_installation(self):
        self.zimInstallPaths = [
            'C:/Program Files/Zim Desktop Wiki/zim.exe',
            'C:/Program Files (x86)/Zim Desktop Wiki/zim.exe',
            ]
        for zimPath in self.zimInstallPaths:
            if os.path.isfile(zimPath):
                return zimPath

        if not self._ui.ask_ok_cancel(_('Zim installation not found. Select now?')):
            return

    def on_close(self):
        self.prjWiki = None

    def open_element_page(self, event=None):
        self._ui.restore_status()
        element = self._ui.propertiesView.activeView.element

        self.set_project_wiki()

        filePath = element.fields.get(ZIM_NOTE_TAG, None)
        initialFilePath = filePath
        if filePath is None:
            filePath = self.create_wiki_page(element)

        if not os.path.isfile(filePath) or not filePath.endswith(ZIM_NOTE_EXTENSION):
            filePath = self.prjWiki.get_note(element.title)
            if filePath is None:
                filePath = filedialog.askopenfilename(
                    filetypes=self._ZimNoteType,
                    defaultextension=self._ZimNoteType[0][1],
                    initialdir=os.path.split(self._mdl.prjFile.filePath)[0]
                    )
            if filePath is None:
                filePath = self.create_wiki_page(element)
                self._ui.set_status(_('Wiki link created'))
                initialFilePath = filePath

            fields = element.fields
            fields[ZIM_NOTE_TAG] = filePath
            element.fields = fields
            if filePath != initialFilePath:
                self._ui.set_status(f"#{_('Broken link fixed')}")
        self.open_zim_page(filePath)

    def set_project_wiki(self):
        if self.prjWiki is None:
            prjWikiPath = self.get_project_wiki_path()
            if prjWikiPath is None:
                return

            self.prjWiki = ZimNotebook(self._mdl.novel, filePath=prjWikiPath)

    def open_project_wiki(self):
        self.set_project_wiki()
        open_document(self.prjWiki.filePath)

    def open_zim_page(self, filePath):
        root, extension = os.path.splitext(filePath)
        if extension != ZIM_NOTE_EXTENSION:
            return False

        launcher = self._ctrl.launchers.get('.zim', '')
        if not os.path.isfile(launcher):
            return False

        pagePath = root.split('/')
        zimPages = []

        while pagePath:
            zimPages.insert(0, pagePath.pop())
            zimPath = '/'.join(pagePath)
            zimNotebook = glob.glob(norm_path(f'{zimPath}/*.zim'))
            if zimNotebook:
                subprocess.Popen([launcher, zimNotebook[0], ":".join(zimPages)])
                return True

        return False

