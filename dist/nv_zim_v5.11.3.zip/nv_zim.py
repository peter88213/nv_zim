"""Zim Desktop Wiki connection plugin for novelibre.

Requires Python 3.7+
Copyright (c) 2025 Peter Triesberger
For further information see https://github.com/peter88213/nv_zim
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
from tkinter import ttk

from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''
    HELP_SITE = None
    HELP_PAGE = None

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

        self._icon = None

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _add_help_menu_entry(self, label):

        def open_help():
            self._ctrl.open_help(
                page=self.HELP_PAGE,
                site=self.HELP_SITE
            )

        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=open_help,
        )

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon


class NvMenu(tk.Menu, SubController):

    def __init__(self):
        super().__init__(tearoff=0)
        self.disableOnLock = []
        self.disableOnClose = []

    def disable_menu(self):
        for label in self.disableOnClose:
            self.entryconfig(label, state='disabled')

    def enable_menu(self):
        for label in self.disableOnClose:
            self.entryconfig(label, state='normal')

    def lock(self):
        for label in self.disableOnLock:
            self.entryconfig(label, state='disabled')

    def unlock(self):
        for label in self.disableOnLock:
            self.entryconfig(label, state='normal')

import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_zim',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

import platform



class GenericMouse:

    REMOVE_PAGE_LINK = '<Shift-Button-1>'


class MacMouse(GenericMouse):

    REMOVE_PAGE_LINK = '<Shift-Button-1>'

if platform.system() == 'Windows':
    PLATFORM = 'win'
    MOUSE = GenericMouse()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    MOUSE = GenericMouse()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    MOUSE = MacMouse()
else:
    PLATFORM = ''
    MOUSE = GenericMouse()

import glob
import subprocess
from tkinter import filedialog

from tkinter import messagebox
from tkinter import ttk


try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message



class SimpleDialog:

    def __init__(self, master,
                 text='', buttons=[], default=None, cancel=None,
                 title=None, class_=None):
        if class_:
            self.root = tk.Toplevel(master, class_=class_)
        else:
            self.root = tk.Toplevel(master)
        if title:
            self.root.title(title)
            self.root.iconname(title)

        _setup_dialog(self.root)

        self.message = tk.Message(
            self.root,
            text=text,
            aspect=400,
            bg='#ffffff',
        )
        self.message.pack(expand=1, fill='both')
        self.frame = ttk.Frame(self.root)
        self.frame.pack()
        self.num = default
        self.cancel = cancel
        self.default = default
        self.root.bind('<Return>', self.return_event)
        for num in range(len(buttons)):
            s = buttons[num]
            b = ttk.Button(
                self.frame,
                text=s,
                command=(lambda self=self, num=num: self.done(num))
                )
            if num == default:
                b.configure(default='active')
            b.pack(side='left', fill='both', expand=1, padx=5, pady=10)
        self.root.protocol('WM_DELETE_WINDOW', self.wm_delete_window)
        self.root.transient(master)
        _place_window(self.root, master)

    def go(self):
        self.root.wait_visibility()
        self.root.lift()
        self.root.focus_force()
        self.root.grab_set()
        self.root.mainloop()
        self.root.destroy()
        return self.num

    def return_event(self, event):
        if self.default is None:
            self.root.bell()
        else:
            self.done(self.default)

    def wm_delete_window(self):
        if self.cancel is None:
            self.root.bell()
        else:
            self.done(self.cancel)

    def done(self, num):
        self.num = num
        self.root.quit()


class Dialog(tk.Toplevel):


    def __init__(self, parent, title=None):
        master = parent
        tk.Toplevel.__init__(self, master)

        self.withdraw()  # remain invisible for now
        if parent is not None and parent.winfo_viewable():
            self.transient(parent)

        if title:
            self.title(title)

        _setup_dialog(self)

        self.parent = parent

        self.result = None

        body = ttk.Frame(self)
        self.initial_focus = self.body(body)
        body.pack(padx=5, pady=5)

        self.buttonbox()

        if self.initial_focus is None:
            self.initial_focus = self

        self.protocol('WM_DELETE_WINDOW', self.cancel)

        _place_window(self, parent)

        self.initial_focus.focus_set()

        self.wait_visibility()
        self.grab_set()
        self.wait_window(self)

    def destroy(self):
        self.initial_focus = None
        tk.Toplevel.destroy(self)


    def body(self, master):
        pass

    def buttonbox(self):

        box = ttk.Frame(self)

        w = ttk.Button(
            box,
            text=_('OK'),
            width=10,
            command=self.ok,
            default='active',
        )
        w.pack(side='left', padx=5, pady=10)
        w = ttk.Button(
            box,
            text=_('Cancel'),
            width=10,
            command=self.cancel,
        )
        w.pack(side='left', padx=5, pady=10)

        self.bind('<Return>', self.ok)
        self.bind('<Escape>', self.cancel)

        box.pack()


    def ok(self, event=None):

        if not self.validate():
            self.initial_focus.focus_set()  # put focus back
            return

        self.withdraw()
        self.update_idletasks()

        try:
            self.apply()
        finally:
            self.cancel()

    def cancel(self, event=None):

        if self.parent is not None:
            self.parent.focus_set()
        self.destroy()


    def validate(self):

        return 1  # override

    def apply(self):

        pass  # override


def _place_window(w, parent=None):
    w.wm_withdraw()  # Remain invisible while we figure out the geometry
    w.wm_resizable(False, False)
    if platform.system() == 'Windows':
        w.attributes('-toolwindow', True)
    w.update_idletasks()  # Actualize geometry information

    minwidth = w.winfo_reqwidth()
    minheight = w.winfo_reqheight()
    maxwidth = w.winfo_vrootwidth()
    maxheight = w.winfo_vrootheight()
    if parent is not None and parent.winfo_ismapped():
        x = parent.winfo_rootx() + (parent.winfo_width() - minwidth) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - minheight) // 2
        vrootx = w.winfo_vrootx()
        vrooty = w.winfo_vrooty()
        x = min(x, vrootx + maxwidth - minwidth)
        x = max(x, vrootx)
        y = min(y, vrooty + maxheight - minheight)
        y = max(y, vrooty)
        if w._windowingsystem == 'aqua':
            y = max(y, 22)
    else:
        x = (w.winfo_screenwidth() - minwidth) // 2
        y = (w.winfo_screenheight() - minheight) // 2

    w.wm_maxsize(maxwidth, maxheight)
    w.wm_geometry('+%d+%d' % (x, y))
    w.wm_deiconify()  # Become visible at the desired location
    w.wm_attributes('-topmost', True)


def _setup_dialog(w):
    if w._windowingsystem == 'aqua':
        w.tk.call('::tk::unsupported::MacWindowStyle', 'style',
                  w, 'moveableModal', '')
    elif w._windowingsystem == 'x11':
        w.wm_attributes('-type', 'dialog')



class _QueryDialog(Dialog):

    def __init__(self, title, prompt,
                 initialvalue=None,
                 minvalue=None, maxvalue=None,
                 parent=None):

        self.prompt = prompt
        self.minvalue = minvalue
        self.maxvalue = maxvalue

        self.initialvalue = initialvalue

        Dialog.__init__(self, parent, title)

    def destroy(self):
        self.entry = None
        Dialog.destroy(self)

    def body(self, master):

        w = ttk.Label(master, text=self.prompt, justify='left')
        w.grid(row=0, padx=5, sticky='w')

        self.entry = ttk.Entry(master, name='entry')
        self.entry.grid(row=1, padx=5, pady=5, sticky='w' + 'e')

        if self.initialvalue is not None:
            self.entry.insert(0, self.initialvalue)
            self.entry.select_range(0, 'end')

        return self.entry

    def validate(self):
        try:
            result = self.getresult()
        except ValueError:
            messagebox.showwarning(
                _('Illegal value'),
                f'{self.errormessage}\n{_("Please try again")}.',
                parent=self
            )
            return 0

        if self.minvalue is not None and result < self.minvalue:
            messagebox.showwarning(
                _('Too small'),
                (
                    f'{_("The allowed minimum value is")} '
                    f'{self.minvalue}.\n{_("Please try again")}.'
                ),
                parent=self
            )
            return 0

        if self.maxvalue is not None and result > self.maxvalue:
            messagebox.showwarning(
                _('Too large'),
                (
                    f'{_("The allowed maximum value is")} '
                    f'{self.maxvalue}.\n{_("Please try again")}.'
                ),
                parent=self,
            )
            return 0

        self.result = result

        return 1


class _QueryInteger(_QueryDialog):
    errormessage = _('Not an integer.')

    def getresult(self):
        return self.getint(self.entry.get())


def askinteger(title, prompt, **kw):
    d = _QueryInteger(title, prompt, **kw)
    return d.result


class _QueryFloat(_QueryDialog):
    errormessage = _('Not a floating point value.')

    def getresult(self):
        return self.getdouble(self.entry.get())


def askfloat(title, prompt, **kw):
    d = _QueryFloat(title, prompt, **kw)
    return d.result


class _QueryString(_QueryDialog):

    def __init__(self, *args, **kw):
        if 'show' in kw:
            self.__show = kw['show']
            del kw['show']
        else:
            self.__show = None
        _QueryDialog.__init__(self, *args, **kw)

    def body(self, master):
        entry = _QueryDialog.body(self, master)
        if self.__show is not None:
            entry.configure(show=self.__show)
        return entry

    def getresult(self):
        return self.entry.get()


def askstring(title, prompt, **kw):
    d = _QueryString(title, prompt, **kw)
    return d.result



ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERLIST_SUFFIX = '_chapterlist_tmp'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHAPTER_BOARD_SUFFFIX = '_sectioncards'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ELEMENT_NOTES_SUFFIX = '_element_note_report',
FULL_MANUSCRIPT_SUFFIX = '_full_tmp'
GRID_REPORT_SUFFIX = '_grid_report'
GRID_SUFFIX = '_grid_tmp'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
METADATA_TEXT_SUFFIX = '_metadata_text_tmp'
MINOR_MARKER = _('Minor Character')
PARTLIST_SUFFIX = '_partlist_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOT_LINE_BOARD_SUFFIX = '_plotcards'
PROJECTNOTES_REPORT_SUFFIX = '_projectnotes_report'
PROJECTNOTES_SUFFIX = '_projectnotes_tmp'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
STORY_STRUCT_BOARD_SUFFIX = '_stagecards'
TIMETABLE_SUFFIX = '_tt_tmp'
VIEWPOINT_BOARD_SUFFFIX = '_viewpoint_board'
XREF_SUFFIX = '_xref'

MAJOR_MARKER = _('Major Character')

NO_SCENE_FIELD_1_DEFAULT = _('Plot progress')
NO_SCENE_FIELD_2_DEFAULT = _('Characterization')
NO_SCENE_FIELD_3_DEFAULT = _('World building')
OTHER_SCENE_FIELD_1_DEFAULT = _('Opening')
OTHER_SCENE_FIELD_2_DEFAULT = _('Peak emotional moment')
OTHER_SCENE_FIELD_3_DEFAULT = _('Ending')
CR_FIELD_1_DEFAULT = _('Bio')
CR_FIELD_2_DEFAULT = _('Goals')

STATUS = [
    None,
    _('Outline'),
    _('Draft'),
    _('1st Edit'),
    _('2nd Edit'),
    _('Done')
]

SCENE = ['-', 'A', 'R', 'x']


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        return divider.join(elements)

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr

from datetime import date

ZIM_NOTEBOOK_ABS_TAG = 'zim-notebook-abs'
ZIM_NOTEBOOK_REL_TAG = 'zim-notebook-rel'
ZIM_PAGE_ABS_TAG = 'zim-page-abs'
ZIM_PAGE_REL_TAG = 'zim-page-rel'


class StopParsing(Exception):
    pass


def locale_date(isoDate):
    try:
        newDate = date.fromisoformat(isoDate)
        return newDate.strftime('%x')

    except:
        return isoDate

import re




class ZimPage:

    DESCRIPTION = _('Zim page')
    EXTENSION = '.txt'

    PAGE_HEADER = (
        'Content-Type: text/x-zim-wiki\n'
        'Wiki-Format: zim 0.4\n'
    )
    REPLACEMENTS = {
        '//':'',
        '**': '',
    }
    invalidChars = re.compile(r'[\:\?\#\/\\\*\"\<"\>\|\%\t\n\r]')

    def __init__(self, filePath, element):
        self.filePath = filePath
        self.element = element
        self.page_names = [self.element.title, _('Untitled')]

    def body(self, text):
        pass

    def fill_page(self, lines):
        pass

    def from_wiki(self, text):
        for tag in self.REPLACEMENTS:
            text = text.replace(tag, self.REPLACEMENTS[tag])
        return text

    def get_h1(self, text):
        return f'====== {text} ======\n'

    def get_h2(self, text):
        return f'===== {text} =====\n'

    def get_h3(self, text):
        return f'==== {text} ====\n'

    def h1(self, heading):
        if self.element.title is None:
            self.element.title = heading

    def h2(self, heading):
        pass

    def h3(self, heading):
        pass

    def new_page_name(self):
        for pageName in self.page_names:
            if pageName is not None:
                return self.invalidChars.sub('', pageName)

    def parse_line(self, line):
        if line.startswith('====== '):
            heading = line.strip('= ')
            self.h1(heading)

        if line.startswith('===== '):
            heading = line.strip('= ')
            self.h2(heading)

        if line.startswith('==== '):
            heading = line.strip('= ')
            self.h3(heading)

        elif not line.startswith('='):
            self.body(line)

    def read(self):
        with open (self.filePath, 'r', encoding='utf-8') as f:
            text = f.read()
        lines = text.split('\n')
        for line in lines:
            try:
                self.parse_line(line)
            except StopParsing:
                return

    def write(self):
        lines = [
            self.PAGE_HEADER,
            f'{self.get_h1(self.new_page_name())}',
        ]
        self.fill_page(lines)
        text = '\n'.join(lines)
        with open (self.filePath, 'w', encoding='utf-8') as f:
            f.write(text)


class WorldElementPage(ZimPage):

    def fill_page(self, lines):
        if self.element.aka:
            lines.append(self.element.aka)
            lines.append('\n')

        if self.element.tags:
            for tag in self.element.tags:
                tag = re.sub(r'\W+', '_', tag)
                lines.append(f"@{tag}")
            lines.append('\n')

        if self.element.desc:
            lines.append(self.element.desc)
            lines.append('\n')


class CharacterPage(WorldElementPage):

    def __init__(
        self,
        filePath,
        element,
        field1Name=f'{_("Field")} 1',
        field2Name=f'{_("Field")} 2',
    ):
        super().__init__(filePath, element)
        self.field1Name = field1Name
        self.field2Name = field2Name
        self.page_names = [
            self.element.fullName,
            self.element.title,
            self.element.aka,
        ]

    def fill_page(self, lines):
        super().fill_page(lines)

        if self.element.bio:
            lines.append(self.get_h2(self.field1Name))
            self._write_life_dates(lines)
            lines.append(self.element.bio)
            lines.append('\n')
        else:
            self._write_life_dates(lines)
            lines.append('\n')

        if self.element.goals:
            lines.append(self.get_h2(self.field2Name))
            lines.append(self.element.goals)
            lines.append('\n')

    def _write_life_dates(self, lines):
        showDate = False
        if self.element.birthDate:
            startDate = locale_date(self.element.birthDate)
            showDate = True
        else:
            startDate = '?'
        if self.element.deathDate:
            endDate = locale_date(self.element.deathDate)
            showDate = True
        else:
            endDate = '?'
        if showDate:
            lines.append(f'{startDate}—{endDate}\n')



class BookPage(ZimPage):

    def fill_page(self, lines):
        if self.element.desc:
            lines.append(self.element.desc)
            lines.append('\n')
            self._add_links(self.element.characters, _('Characters'), lines)
            self._add_links(self.element.locations, _('Locations'), lines)
            self._add_links(self.element.items, _('Items'), lines)

    def _add_links(self, elements, heading, lines):
        linkLines = []
        homeDir = os.path.dirname(self.filePath)
        for elemId in elements:
            elemPage = self._new_zim_page(elements[elemId], elemId)
            pageName = elemPage.new_page_name()
            filePath = (
                f"{homeDir}/{pageName.replace(' ', '_')}"
                f"{elemPage.EXTENSION}"
            )
            if os.path.isfile(filePath):
                linkLines.append(f'[[{pageName}]]')
        if linkLines:
            lines.append(self.get_h2(heading))
            lines.extend(sorted(linkLines))
            lines.append('\n')

    def _new_zim_page(self, element, elemId):


        if elemId.startswith(CHARACTER_PREFIX):
            return CharacterPage(None, element)

        if elemId.startswith(LOCATION_PREFIX):
            return WorldElementPage(None, element)

        if elemId.startswith(ITEM_PREFIX):
            return WorldElementPage(None, element)


class WikiFactory:

    def __init__(self, model):
        self._mdl = model

    def new_wiki_page(self, element, elemId, filePath):
        if elemId == CH_ROOT:
            return BookPage(filePath, element)

        if elemId.startswith(CHARACTER_PREFIX):
            return CharacterPage(
                filePath,
                element,
                field1Name=self._mdl.novel.crField1,
                field2Name=self._mdl.novel.crField2,
            )

        if elemId.startswith(LOCATION_PREFIX):
            return WorldElementPage(filePath, element)

        if elemId.startswith(ITEM_PREFIX):
            return WorldElementPage(filePath, element)

from configparser import ConfigParser



class ZimNotebook:

    DESCRIPTION = _('Zim notebook')
    EXTENSION = '.zim'

    NOTEBOOK = 'Notebook'
    HOME = 'Home'

    def __init__(self, zimApp, dirPath='', filePath='', wikiName=None):
        self.zimApp = zimApp

        if wikiName is None:
            wikiName = self.NOTEBOOK
        self.settings = dict(
            version='0.4',
            name=wikiName,
            interwiki='',
            home=self.HOME,
            icon='',
            document_root='',
            shared='True',
            endofline='dos',
            disable_trash='False',
            profile='',
        )
        if os.path.isfile(filePath):
            self.filePath = filePath
            self.dirPath = os.path.dirname(filePath)
            self.filePath = filePath
            self.read_settings()
            self.homeDir = f"{self.dirPath}/{self.settings['home']}"
        elif os.path.isdir(dirPath):
            self.dirPath = dirPath
            self.filePath = f'{dirPath}/{self.NOTEBOOK}.zim'
            self.homeDir = f'{self.dirPath}/{self.HOME}'
            self.write()
            self.update_index()
        else:
            raise AttributeError

    def open(self, initialPage=None):
        if not os.path.isfile(self.filePath):
            raise RuntimeError

        wikiStart = [
            self.zimApp,
            self.dirPath
        ]
        if initialPage is not None:
            wikiStart.append(initialPage)
        subprocess.Popen(wikiStart)

    def read_settings(self):
        notebook = ConfigParser()
        notebook.read(self.filePath, encoding='utf-8')
        for tag in self.settings:
            self.settings[tag] = notebook.get(self.NOTEBOOK, tag)

    def update_index(self):
        if not os.path.isfile(self.filePath):
            return

        subprocess.Popen(
            [
                self.zimApp,
                '--index',
                self.filePath,
            ]
        )

    def write(self):

        def get_sanitized(text):
            return text.replace('%', '')

        notebook = ConfigParser()
        notebook.add_section(self.NOTEBOOK)
        for tag in self.settings:
            notebook.set(
                self.NOTEBOOK,
                tag,
                get_sanitized(self.settings[tag])
            )
        with open(self.filePath, 'w', encoding='utf-8') as f:
            notebook.write(f)
        os.makedirs(self.homeDir, exist_ok=True)

    def get_page_path_by_name(self, pageName):
        workdir = os.getcwd()
        os.chdir(self.homeDir)
        foundFiles = glob.glob(
            f"**/{pageName.replace(' ', '_')}{ZimPage.EXTENSION}",
            recursive=True,
        )
        os.chdir(workdir)
        if foundFiles:
            foundFile = foundFiles[0].replace('\\', '/')
            return f'{self.homeDir}/{foundFile}'



class WikiManager(SubController):

    def __init__(self, model, view, controller, windowTitle):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self.prjWiki = None
        self.launchers = self._ctrl.get_launchers()
        self.zimApp = self.launchers.get(ZimNotebook.EXTENSION, '')
        self.windowTitle = windowTitle
        self.wikiFactory = WikiFactory(self._mdl)

    def check_home_dir(self):
        if self.prjWiki is None:
            return

        if not os.path.isdir(self.prjWiki.homeDir):
            os.makedirs(self.prjWiki.homeDir)

    def create_blank_prj_notebook(self, prjWikiDir):
        os.makedirs(prjWikiDir, exist_ok=True)
        self.prjWiki = ZimNotebook(
            self.zimApp,
            dirPath=prjWikiDir,
            wikiName=self._mdl.novel.title
            )
        self.set_notebook_links(self.prjWiki.filePath)
        self._ui.set_status(
            f'{_("Wiki created")}: "{norm_path(self.prjWiki.filePath)}"'
        )

    def create_project_wiki(self):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        if self._mdl.prjFile.filePath is None:
            self._ui.set_status(
                f"!{_('Cannot define a project wiki without project path')}."
            )
            return

        prjWikiDir = self.get_project_wiki_dir()
        if os.path.isdir(prjWikiDir):
            if not self._ui.ask_yes_no(
                _('Back up the existing wiki and create a new one containing all pages?'),
                title=self.windowTitle
                ):
                return

            backupWikiDir = f'{prjWikiDir}.bak'
            while os.path.isdir(backupWikiDir):
                backupWikiDir = f'{backupWikiDir}_'
            os.rename(prjWikiDir, backupWikiDir)

        self.create_blank_prj_notebook(prjWikiDir)
        sources = [
            self._mdl.novel.characters,
            self._mdl.novel.locations,
            self._mdl.novel.items,
        ]
        for source in sources:
            for elemId in source:
                self.create_wiki_page(source[elemId], elemId)
            bookPageName = self.create_wiki_page(self._mdl.novel, CH_ROOT)

        self.prjWiki.update_index()
        self._ui.set_status(
            (
                f'{_("Wiki created")}: '
                f'"{norm_path(self.prjWiki.filePath)}"'
             )
        )
        self.prjWiki.open(initialPage=f'{self.prjWiki.HOME}:{bookPageName}')

    def create_wiki_page(self, element, elemId):
        newPage = self.wikiFactory.new_wiki_page(element, elemId, None)
        newPageName = newPage.new_page_name()
        newPage.filePath = (
            f"{self.prjWiki.homeDir}/{newPageName.replace(' ', '_')}"
            f"{newPage.EXTENSION}"
        )
        newPage.write()
        self.set_page_links(element, newPage.filePath)
        return newPageName

    def get_element(self, elemId):
        if elemId.startswith(PLOT_LINE_PREFIX):
            return self._mdl.novel.plotLines[elemId]

        if elemId.startswith(CHARACTER_PREFIX):
            return self._mdl.novel.characters[elemId]

        if elemId.startswith(LOCATION_PREFIX):
            return self._mdl.novel.locations[elemId]

        if elemId.startswith(ITEM_PREFIX):
            return self._mdl.novel.items[elemId]

        if elemId == CH_ROOT:
            return self._mdl.novel

    def get_project_wiki_dir(self):
        if self._mdl.prjFile.filePath is None:
            return

        prjDir, prjFile = os.path.split(self._mdl.prjFile.filePath)
        prjFileBase = os.path.splitext(prjFile)[0]
        return f'{prjDir}/{prjFileBase}_zim'

    def get_project_wiki_link(self):
        if self._mdl.prjFile is None:
            return

        prjWikiPath = self._mdl.novel.fields.get(ZIM_NOTEBOOK_ABS_TAG, '')
        if not os.path.isfile(prjWikiPath):
            prjWikiPath = self._mdl.novel.fields.get(
                ZIM_NOTEBOOK_REL_TAG, None
            )
            if prjWikiPath is None:
                return

            prjWikiPath = self._ctrl.linkProcessor.expand_path(prjWikiPath)

        if not prjWikiPath.endswith(ZimNotebook.EXTENSION):
            return

        if os.path.isfile(prjWikiPath):
            return prjWikiPath

    def get_wiki_page_link(self, element):
        wikiPagePath = element.fields.get(ZIM_PAGE_ABS_TAG, '')
        if not os.path.isfile(wikiPagePath):
            wikiPagePath = element.fields.get(ZIM_PAGE_REL_TAG, None)
            if wikiPagePath is None:
                return

            wikiPagePath = self._ctrl.linkProcessor.expand_path(wikiPagePath)

        if not wikiPagePath.endswith(ZimPage.EXTENSION):
            return

        if os.path.isfile(wikiPagePath):
            return wikiPagePath

    def on_close(self):
        self.prjWiki = None

    def open_element_page(self):
        self.open_page_by_id(self._ui.propertiesView.activeView.elementId)

    def open_page_by_id(self, elemId):
        self._ui.restore_status()
        if self._mdl.prjFile.filePath is None:
            self._ui.set_status(
                f"!{_('Cannot define a project wiki without project path')}."
            )
            return

        element = self.get_element(elemId)

        filePath = self.get_wiki_page_link(element)
        pageCreated = False

        if filePath is None:

            wikiPage = self.wikiFactory.new_wiki_page(element, elemId, None)
            self.set_project_wiki()
            if self.prjWiki is None:
                return

            for pageName in wikiPage.page_names:
                if pageName:
                    filePath = self.prjWiki.get_page_path_by_name(pageName)
                    if filePath is not None:
                        if self._ui.ask_yes_no(
                            title=_('Matching page found'),
                            message=_('Open this page and create a link?'),
                            detail=os.path.normpath(filePath)
                        ):
                            break
                        else:
                            filePath = None

        if filePath is None:

            text = (
                f"{_('Wiki page not found')}\n\n"
                f"{_('Open an existing page, or create a new one?')}"
            )
            answer = SimpleDialog(
                None,
                text=text,
                buttons=[_('Browse'), _('Create'), _('Cancel')],
                default=0,
                cancel=2,
                title=self.windowTitle
                ).go()

            if answer == 2:
                return

            if answer == 0:

                if self.prjWiki is not None:
                    initialDir = self.prjWiki.homeDir
                else:
                    initialDir = os.path.dirname(self._mdl.prjFile.filePath)
                filePath = filedialog.askopenfilename(
                    filetypes=[(ZimPage.DESCRIPTION, ZimPage.EXTENSION)],
                    defaultextension=ZimPage.EXTENSION,
                    initialdir=initialDir
                )
                if not filePath:
                    return

            else:
                if self.prjWiki is None:
                    return

                self.check_home_dir()
                fileName = wikiPage.new_page_name().replace(' ', '_')
                filePath = (
                    f'{self.prjWiki.homeDir}/{fileName}{wikiPage.EXTENSION}'
                )
                wikiPage.filePath = filePath
                wikiPage.write()
                pageCreated = True

        self.set_page_links(element, filePath)
        if pageCreated:
            self._ui.set_status(f"{_('Wiki page created')}.")
            self.prjWiki.update_index()
        self.open_page_file(filePath)

    def open_page_file(self, filePath):
        if not self.zim_is_installed():
            self._ui.set_status(f'!{_("Zim installation not found")}.')
            return False

        root, extension = os.path.splitext(filePath)
        if extension != ZimPage.EXTENSION:
            return False

        pagePath = root.split('/')
        zimPages = []

        while pagePath:
            zimPages.insert(0, pagePath.pop())
            zimPath = '/'.join(pagePath)
            zimNotebook = glob.glob(
                norm_path(f'{zimPath}/*{ZimNotebook.EXTENSION}')
            )
            if zimNotebook:
                subprocess.Popen(
                    [
                        self.zimApp,
                        zimNotebook[0],
                        ":".join(zimPages)
                    ]
                )
                return True

        return False

    def open_project_wiki(self):
        if self._mdl.prjFile is None:
            return

        self._ui.restore_status()
        self._ui.propertiesView.apply_changes()
        if not self.zim_is_installed():
            self._ui.set_status(f'!{_("Zim installation not found")}.')
            return

        self.set_project_wiki()
        self.check_home_dir()
        if self.prjWiki is not None:
            try:
                self.prjWiki.open()
            except RuntimeError:
                self._ui.set_status(f'!{_("Project wiki not found")}.')

    def remove_all_links(self):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        if self._ctrl.check_lock():
            return

        if not self._ui.ask_yes_no(
            _('Remove all Zim wiki links?'),
            title=self.windowTitle
        ):
            return

        removed = False
        if self.remove_notebook_links():
            self.prjWiki = None
            removed = True
        if self.remove_page_links(self._mdl.novel):
            removed = True
        for elemId in self._mdl.novel.plotLines:
            if self.remove_page_links(self._mdl.novel.plotLines[elemId]):
                removed = True
        for elemId in self._mdl.novel.characters:
            if self.remove_page_links(self._mdl.novel.characters[elemId]):
                removed = True
        for elemId in self._mdl.novel.locations:
            if self.remove_page_links(self._mdl.novel.locations[elemId]):
                removed = True
        for elemId in self._mdl.novel.items:
            if self.remove_page_links(self._mdl.novel.items[elemId]):
                removed = True
        self.set_removal_status(removed)

    def remove_notebook_links(self):
        removed = False
        fields = self._mdl.novel.fields
        try:
            del(fields[ZIM_NOTEBOOK_ABS_TAG])
            removed = True
        except KeyError:
            pass
        try:
            del(fields[ZIM_NOTEBOOK_REL_TAG])
            removed = True
        except KeyError:
            pass
        self._mdl.novel.fields = fields
        return removed

    def remove_page_links(self, element):
        removed = False
        fields = element.fields
        try:
            del (fields[ZIM_PAGE_ABS_TAG])
            removed = True
        except KeyError:
            pass
        try:
            del (fields[ZIM_PAGE_REL_TAG])
            removed = True
        except KeyError:
            pass
        element.fields = fields
        return removed

    def remove_page_link_after_asking(self):
        element = self.get_element(
            self._ui.propertiesView.activeView.elementId
        )
        self._ui.restore_status()
        if self._ctrl.isLocked:
            return

        fields = element.fields
        initialAbsPath = fields.get(ZIM_PAGE_ABS_TAG, None)
        initialRelPath = fields.get(ZIM_PAGE_REL_TAG, None)
        if initialAbsPath is None and initialRelPath is None:
            return

        if not self._ui.ask_yes_no(_('Remove wiki link?')):
            return

        if self.remove_page_links(element):
            self._ui.set_status(f"#{_('Wiki link removed')}.")

    def remove_selected_page_links(self):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        if self._ctrl.check_lock():
            return

        for elemId in self._ui.selectedNodes:
            element = self.get_element(elemId)
            if elemId[:2] in (
                PLOT_LINE_PREFIX,
                CHARACTER_PREFIX,
                LOCATION_PREFIX,
                ITEM_PREFIX) or elemId in (
                    CH_ROOT,
                    CR_ROOT,
                    LC_ROOT,
                    IT_ROOT,
                    PL_ROOT,
            ):
                if self._ui.ask_yes_no(
                    _('Remove the Zim wiki links of the selected elements?'),
                    title=self.windowTitle
                ):
                    break
                else:
                    return

        removed = False
        for elemId in self._ui.selectedNodes:
            element = self.get_element(elemId)
            if element is not None:
                if self.remove_page_links(element):
                    removed = True
            else:
                if elemId == PL_ROOT:
                    for elemId in self._mdl.novel.plotLines:
                        if self.remove_page_links(
                            self._mdl.novel.plotLines[elemId]
                        ):
                            removed = True
                elif elemId == CR_ROOT:
                    for elemId in self._mdl.novel.characters:
                        if self.remove_page_links(
                            self._mdl.novel.characters[elemId]
                        ):
                            removed = True
                elif elemId == LC_ROOT:
                    for elemId in self._mdl.novel.locations:
                        if self.remove_page_links(
                            self._mdl.novel.locations[elemId]
                        ):
                            removed = True
                elif elemId == IT_ROOT:
                    for elemId in self._mdl.novel.items:
                        if self.remove_page_links(
                            self._mdl.novel.items[elemId]
                        ):
                            removed = True
        self.set_removal_status(removed)

    def set_removal_status(self, removed):
        if removed:
            self._ui.set_status(f"{_('Wiki link(s) removed')}.")
        else:
            self._ui.set_status(f"#{_('No Wiki link found')}.")

    def set_notebook_links(self, prjWikiPath):
        self._ui.restore_status()
        if self._ctrl.isLocked:
            return

        fields = self._mdl.novel.fields
        initialAbsPath = fields.get(ZIM_NOTEBOOK_ABS_TAG, None)
        initialRelPath = fields.get(ZIM_NOTEBOOK_REL_TAG, None)
        fields[ZIM_NOTEBOOK_ABS_TAG] = prjWikiPath
        relPath = self._ctrl.linkProcessor.shorten_path(prjWikiPath)
        fields[ZIM_NOTEBOOK_REL_TAG] = relPath
        self._mdl.novel.fields = fields
        message = None
        if initialAbsPath is None or initialRelPath is None:
            message = f"#{_('Wiki link created')}."
        elif initialAbsPath != prjWikiPath  or initialRelPath != relPath:
            message = f"#{_('Broken link fixed')}."
        if message is not None:
            self._ui.set_status(message)

    def set_page_links(self, element, wikiPagePath):
        self._ui.restore_status()
        if self._ctrl.isLocked:
            return

        fields = element.fields
        initialAbsPath = fields.get(ZIM_PAGE_ABS_TAG, None)
        initialRelPath = fields.get(ZIM_PAGE_REL_TAG, None)
        fields[ZIM_PAGE_ABS_TAG] = wikiPagePath
        relPath = self._ctrl.linkProcessor.shorten_path(wikiPagePath)
        fields[ZIM_PAGE_REL_TAG] = relPath
        element.fields = fields
        message = None
        if initialAbsPath is None or initialRelPath is None:
            message = f"#{_('Wiki link created')}."
        elif initialAbsPath != wikiPagePath  or initialRelPath != relPath:
            message = f"#{_('Broken link fixed')}."
        if message is not None:
            self._ui.set_status(message)

    def set_project_wiki(self):
        self._ui.restore_status()
        if self._mdl.prjFile.filePath is None:
            self._ui.set_status(
                f"!{_('Cannot define a project wiki without project path')}."
            )
            return

        if self.prjWiki is not None:
            return

        prjWikiPath = self.get_project_wiki_link()
        if prjWikiPath is not None and os.path.isfile(prjWikiPath):

            self.prjWiki = ZimNotebook(self.zimApp, filePath=prjWikiPath)
            self.set_notebook_links(self.prjWiki.filePath)
            return

        text = (
            f"{_('Project wiki not found')}.\n\n"
            f"{_('Open an existing wiki, or create a new one?')}"
        )
        answer = SimpleDialog(
            None,
            text=text,
            buttons=[_('Browse'), _('Create'), _('Cancel')],
            default=0,
            cancel=2,
            title=self.windowTitle
            ).go()
        if answer == 2:
            return

        if answer == 0:

            prjWikiPath = filedialog.askopenfilename(
                filetypes=[(ZimNotebook.DESCRIPTION, ZimNotebook.EXTENSION)],
                defaultextension=ZimNotebook.EXTENSION,
                initialdir=os.path.dirname(self._mdl.prjFile.filePath),
            )
            if not prjWikiPath:
                return

            self.prjWiki = ZimNotebook(self.zimApp, filePath=prjWikiPath)
            self.set_notebook_links(self.prjWiki.filePath)
        else:
            self.create_blank_prj_notebook(self.get_project_wiki_dir())

    def zim_is_installed(self):
        if os.path.isfile(self.zimApp):
            self.launchers[ZimNotebook.EXTENSION] = self.zimApp
            return True

        self.zimInstallPaths = [
            'C:/Program Files/Zim Desktop Wiki/zim.exe',
            'C:/Program Files (x86)/Zim Desktop Wiki/zim.exe',
            '/usr/bin/zim',
        ]
        for zimPath in self.zimInstallPaths:
            if os.path.isfile(zimPath):
                self.zimApp = zimPath
                self.launchers[ZimNotebook.EXTENSION] = self.zimApp
                return True

        if not self._ui.ask_yes_no(
            _('Zim installation not found. Select now?'),
            title=self.windowTitle,
        ):
            return

        zimPath = filedialog.askopenfilename()
        if not zimPath:
            return

        self.zimApp = zimPath
        self.launchers[ZimNotebook.EXTENSION] = self.zimApp
        if self.prjWiki is not None:
            self.prjWiki.zimApp = self.zimApp
        return True



class Plugin(PluginBase):
    VERSION = '5.11.3'
    API_VERSION = '5.63'
    DESCRIPTION = 'Zim Desktop Wiki connection'
    URL = 'https://github.com/peter88213/nv_zim'
    HELP_PAGE = 'nv_zim'

    FEATURE = 'Zim Desktop Wiki'

    def install(self, model, view, controller):
        """Install the plugin at runtime.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.wikiManager = WikiManager(
            model,
            view,
            controller,
            self.FEATURE
        )
        self._icon = self._get_icon('zim.png')


        def open_link(filePath):
            return self.wikiManager.open_page_file(filePath)

        self.zimMenu = NvMenu()

        label = _('Open project wiki')
        self.zimMenu.add_command(
            label=label,
            command=self.wikiManager.open_project_wiki,
        )

        label = _('Create project wiki')
        self.zimMenu.add_separator()
        self.zimMenu.add_command(
            label=label,
            command=self.wikiManager.create_project_wiki,
        )
        self.zimMenu.disableOnLock.append(label)

        self.zimMenu.add_separator()

        removeLinksMenu = tk.Menu(tearoff=0)

        label = _('Selected pages')
        removeLinksMenu.add_command(
            label=label,
            command=self.wikiManager.remove_selected_page_links,
        )

        label = _('All')
        removeLinksMenu.add_command(
            label=label,
            command=self.wikiManager.remove_all_links,
        )

        label = _('Remove wiki links')
        self.zimMenu.add_cascade(
            label=label,
            menu=removeLinksMenu,
        )
        self.zimMenu.disableOnLock.append(label)

        label = _('Zim Desktop Wiki')
        self._ui.toolsMenu.add_cascade(
            label=label,
            image=self._icon,
            compound='left',
            menu=self.zimMenu,
        )
        self._ui.toolsMenu.disableOnClose.append(label)

        self._add_help_menu_entry(_('Zim connection plugin help'))

        self._ctrl.linkProcessor.add_opener(open_link)

        self._add_buttons()
        self._ui.root.bind('<<RebuildPropertiesView>>', self._add_buttons)

        self._ui.toolbar.add_separator(),

        self._ui.toolbar.new_button(
            text=self.FEATURE,
            image=self._icon,
            command=self.wikiManager.open_project_wiki,
            disableOnLock=False,
        ).pack(side='left')

    def lock(self):
        self.zimMenu.lock()

    def on_close(self):
        self.wikiManager.on_close()

    def unlock(self):
        self.zimMenu.unlock()

    def _add_buttons(self, event=None):

        def remove_page_link(event=None):
            self.wikiManager.remove_page_link_after_asking()

        enableHovertips = self._ctrl.get_preferences()['enable_hovertips']
        Hovertip = self._mdl.nvService.new_hovertip
        views = [
            self._ui.propertiesView.characterView,
            self._ui.propertiesView.locationView,
            self._ui.propertiesView.itemView,
            self._ui.propertiesView.projectView,
        ]
        for view in views:
            zimButton = ttk.Button(
                view.linksWindow.titleBar,
                text=_('Wiki page'),
                image=self._icon,
                command=self.wikiManager.open_element_page,
            )
            zimButton.pack(side='right')
            zimButton.bind(MOUSE.REMOVE_PAGE_LINK, remove_page_link)

            if enableHovertips:
                Hovertip(zimButton, zimButton['text'])

